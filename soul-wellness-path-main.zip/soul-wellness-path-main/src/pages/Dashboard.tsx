
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import PageContainer from '@/components/PageContainer';
import { BarChart, Calendar, MessageCircle, Heart, Clock, Activity, ArrowRight, BarChart2 } from 'lucide-react';

interface AnalysisResult {
  wellbeingScore: number;
  strengthAreas: string[];
  improvementAreas: string[];
  recommendations: string[];
}

// Mock analysis results based on questionnaire
const generateAnalysis = (): AnalysisResult => {
  return {
    wellbeingScore: Math.floor(Math.random() * 31) + 60, // Score between 60-90
    strengthAreas: [
      "Social connections and relationships",
      "Self-awareness and personal insight",
      "Resilience when facing challenges"
    ],
    improvementAreas: [
      "Stress management techniques",
      "Consistent sleep patterns",
      "Work-life balance"
    ],
    recommendations: [
      "Practice daily mindfulness meditation for 5-10 minutes",
      "Establish a consistent sleep schedule",
      "Set boundaries with work demands",
      "Incorporate regular physical activity into your routine",
      "Consider journaling to track emotional patterns"
    ]
  };
};

export default function Dashboard() {
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState(true);
  
  // Mock recent mood entries
  const moodData = [
    { day: "Mon", mood: 7 },
    { day: "Tue", mood: 6 },
    { day: "Wed", mood: 8 },
    { day: "Thu", mood: 7 },
    { day: "Fri", mood: 9 }
  ];
  
  // Load data
  useEffect(() => {
    // Simulate API call to get analysis
    setTimeout(() => {
      setAnalysis(generateAnalysis());
      setLoading(false);
    }, 1000);
  }, []);
  
  const getScoreCategory = (score: number) => {
    if (score >= 80) return { label: "Excellent", color: "text-green-500" };
    if (score >= 70) return { label: "Good", color: "text-wellness-primary" };
    if (score >= 60) return { label: "Fair", color: "text-amber-500" };
    return { label: "Needs Attention", color: "text-red-500" };
  };
  
  // Get current user's first name
  const getUserFirstName = () => {
    const userString = localStorage.getItem('user');
    if (userString) {
      const user = JSON.parse(userString);
      return user.name.split(' ')[0];
    }
    return 'there';
  };
  
  return (
    <PageContainer>
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">
            Hello {getUserFirstName()}, here's your mental wellness overview
          </p>
        </div>
        
        {loading ? (
          <div className="flex items-center justify-center min-h-[400px]">
            <div className="animate-pulse space-y-2 text-center">
              <div className="h-8 w-32 bg-muted rounded mx-auto"></div>
              <p className="text-muted-foreground">Loading your wellness insights...</p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Wellbeing Score Card */}
            <Card className="wellness-card md:col-span-1">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2">
                  <Activity size={20} className="text-wellness-primary" />
                  <span>Wellbeing Score</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-2">
                <div className="flex flex-col items-center justify-center">
                  <div className="relative flex items-center justify-center">
                    <svg className="h-36 w-36">
                      <circle
                        cx="72"
                        cy="72"
                        r="60"
                        fill="none"
                        strokeWidth="8"
                        stroke="#e5e7eb"
                      />
                      <circle
                        cx="72"
                        cy="72"
                        r="60"
                        fill="none"
                        strokeWidth="8"
                        stroke="#9B87F5"
                        strokeDasharray={`${(analysis?.wellbeingScore ?? 0) * 3.77} 377`}
                        strokeDashoffset="0"
                        transform="rotate(-90 72 72)"
                      />
                    </svg>
                    <div className="absolute text-center">
                      <div className="text-4xl font-bold">{analysis?.wellbeingScore}</div>
                      <div className="text-sm">out of 100</div>
                    </div>
                  </div>
                  <div className={`font-medium text-lg mt-2 ${getScoreCategory(analysis?.wellbeingScore ?? 0).color}`}>
                    {getScoreCategory(analysis?.wellbeingScore ?? 0).label}
                  </div>
                </div>
              </CardContent>
              <CardFooter className="pt-0">
                <Button asChild variant="link" className="mx-auto">
                  <Link to="/questionnaire" className="flex items-center gap-1">
                    <span>Retake Assessment</span>
                    <ArrowRight size={16} />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
            
            {/* Mood Trends Card */}
            <Card className="wellness-card md:col-span-2">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <BarChart2 size={20} className="text-wellness-secondary" />
                    <span>Recent Mood Trends</span>
                  </CardTitle>
                  <Button asChild variant="ghost" size="sm">
                    <Link to="/mood" className="flex items-center gap-1">
                      <span>View Full History</span>
                      <ArrowRight size={14} />
                    </Link>
                  </Button>
                </div>
                <CardDescription>
                  Your mood patterns over the past week
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-2">
                <div className="flex items-end justify-between h-40 mt-6">
                  {moodData.map((day, i) => (
                    <div key={i} className="flex flex-col items-center w-full">
                      <div 
                        className="bg-wellness-primary/80 rounded-t-md w-12"
                        style={{ height: `${day.mood * 10}%` }}
                      ></div>
                      <div className="mt-2 text-sm font-medium">{day.day}</div>
                      <div className="text-xs text-muted-foreground">{day.mood}/10</div>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter className="flex justify-between pt-0">
                <div className="text-sm text-muted-foreground">
                  Average: <span className="font-medium">7.4/10</span>
                </div>
                <Button asChild className="wellness-button-secondary">
                  <Link to="/mood" className="flex items-center gap-1">
                    <span>Log Today's Mood</span>
                    <ArrowRight size={16} />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
            
            {/* Strength Areas Card */}
            <Card className="wellness-card">
              <CardHeader className="pb-2">
                <CardTitle>Your Strength Areas</CardTitle>
                <CardDescription>
                  Based on your assessment, you excel in:
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {analysis?.strengthAreas.map((strength, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <div className="h-5 w-5 rounded-full bg-green-500/20 flex items-center justify-center shrink-0 mt-0.5">
                        <span className="text-green-600 text-xs">✓</span>
                      </div>
                      <span>{strength}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
            
            {/* Improvement Areas Card */}
            <Card className="wellness-card">
              <CardHeader className="pb-2">
                <CardTitle>Areas for Growth</CardTitle>
                <CardDescription>
                  Consider focusing on these aspects:
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {analysis?.improvementAreas.map((area, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <div className="h-5 w-5 rounded-full bg-amber-500/20 flex items-center justify-center shrink-0 mt-0.5">
                        <span className="text-amber-600 text-xs">!</span>
                      </div>
                      <span>{area}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
            
            {/* Recommendations Card */}
            <Card className="wellness-card md:col-span-1">
              <CardHeader className="pb-2">
                <CardTitle>Personalized Recommendations</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {analysis?.recommendations.map((rec, index) => (
                    <li key={index} className="pb-3 border-b border-border last:border-b-0 last:pb-0">
                      <div className="flex items-start gap-2">
                        <div className="h-5 w-5 rounded-full bg-wellness-accent flex items-center justify-center shrink-0 mt-0.5">
                          <span className="text-wellness-primary text-xs font-bold">{index + 1}</span>
                        </div>
                        <span>{rec}</span>
                      </div>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        )}
        
        {/* Quick Access Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-8">
          <Card className="wellness-card bg-wellness-accent">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-wellness-primary flex items-center justify-center">
                  <MessageCircle size={24} className="text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Chat Support</h3>
                  <p className="text-sm text-muted-foreground mb-4">Talk to our AI assistant</p>
                  <Button asChild size="sm" className="wellness-button-primary">
                    <Link to="/chat">Start Chat</Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="wellness-card bg-wellness-accent">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-wellness-secondary flex items-center justify-center">
                  <Heart size={24} className="text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Coping Tools</h3>
                  <p className="text-sm text-muted-foreground mb-4">Breathing, journaling & more</p>
                  <Button asChild size="sm" className="wellness-button-secondary">
                    <Link to="/tools">Explore Tools</Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="wellness-card bg-wellness-accent">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-wellness-primary flex items-center justify-center">
                  <Calendar size={24} className="text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Track Mood</h3>
                  <p className="text-sm text-muted-foreground mb-4">Monitor your emotional health</p>
                  <Button asChild size="sm" className="wellness-button-primary">
                    <Link to="/mood">Log Mood</Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="wellness-card bg-wellness-accent">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-wellness-secondary flex items-center justify-center">
                  <Clock size={24} className="text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Daily Tip</h3>
                  <p className="text-sm text-muted-foreground mb-4">Practice deep breathing daily</p>
                  <Button asChild size="sm" className="wellness-button-secondary">
                    <Link to="/tools">Try Now</Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
