
import { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import PageContainer from '@/components/PageContainer';
import { Play, Pause, Save, RefreshCw, CheckCircle, Clock, BookOpen, Music, Lightbulb } from 'lucide-react';

const journalPrompts = [
  "What are three things you're grateful for today?",
  "Describe a challenge you're currently facing and three ways you might approach it.",
  "What activities make you feel most energized and fulfilled?",
  "Write about a time when you felt proud of yourself. What did you learn from that experience?",
  "What are some self-care practices that help you feel grounded?",
  "What would you tell a friend who was going through what you're experiencing now?",
  "What are your top priorities right now, and are your daily actions aligned with them?"
];

const getRandomPrompt = () => {
  const randomIndex = Math.floor(Math.random() * journalPrompts.length);
  return journalPrompts[randomIndex];
};

const cbtTips = [
  {
    title: "Recognize Cognitive Distortions",
    description: "Learn to identify thought patterns that are irrational or exaggerated, such as all-or-nothing thinking, catastrophizing, or overgeneralization."
  },
  {
    title: "Challenge Negative Thoughts",
    description: "When negative thoughts arise, ask yourself: What evidence supports this thought? Is there another way to look at this situation? What would I tell a friend in this situation?"
  },
  {
    title: "Practice Mindfulness",
    description: "Stay present in the moment without judgment. Notice your thoughts and feelings without getting caught up in them."
  },
  {
    title: "Behavioral Activation",
    description: "Engage in positive activities that bring you a sense of achievement, enjoyment, or connection with others, even when you don't feel like it."
  },
  {
    title: "Set Realistic Goals",
    description: "Break down larger goals into small, achievable steps. Celebrate your progress along the way."
  }
];

export default function CopingTools() {
  // Breathing exercise state
  const [breathingPhase, setBreathingPhase] = useState<'idle' | 'inhale' | 'hold' | 'exhale'>('idle');
  const [isBreathingActive, setIsBreathingActive] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [totalBreaths, setTotalBreaths] = useState(0);
  
  // Journal state
  const [journalPrompt, setJournalPrompt] = useState(() => getRandomPrompt());
  const [journalEntry, setJournalEntry] = useState('');
  const [savedEntries, setSavedEntries] = useState<string[]>([]);
  
  // Refs for timers
  const breathingTimerRef = useRef<NodeJS.Timeout | null>(null);
  const { toast } = useToast();
  
  // Initialize journal entries from localStorage
  useEffect(() => {
    const storedEntries = localStorage.getItem('journalEntries');
    if (storedEntries) {
      setSavedEntries(JSON.parse(storedEntries));
    }
  }, []);
  
  // Handle breathing exercise
  useEffect(() => {
    if (isBreathingActive) {
      breathingTimerRef.current = setInterval(() => {
        setSeconds(prev => {
          const newSeconds = prev + 1;
          
          // 4-7-8 breathing technique
          if (breathingPhase === 'inhale' && newSeconds >= 4) {
            setBreathingPhase('hold');
            return 0;
          } else if (breathingPhase === 'hold' && newSeconds >= 7) {
            setBreathingPhase('exhale');
            return 0;
          } else if (breathingPhase === 'exhale' && newSeconds >= 8) {
            setBreathingPhase('inhale');
            setTotalBreaths(prev => prev + 1);
            return 0;
          }
          
          return newSeconds;
        });
      }, 1000);
    } else if (breathingTimerRef.current) {
      clearInterval(breathingTimerRef.current);
      breathingTimerRef.current = null;
    }
    
    return () => {
      if (breathingTimerRef.current) {
        clearInterval(breathingTimerRef.current);
      }
    };
  }, [isBreathingActive, breathingPhase]);
  
  const toggleBreathing = () => {
    if (!isBreathingActive) {
      setBreathingPhase('inhale');
      setSeconds(0);
      setIsBreathingActive(true);
    } else {
      setBreathingPhase('idle');
      setIsBreathingActive(false);
    }
  };
  
  const getBreathingInstruction = () => {
    switch (breathingPhase) {
      case 'inhale':
        return `Inhale slowly through your nose (${4 - seconds}s)`;
      case 'hold':
        return `Hold your breath (${7 - seconds}s)`;
      case 'exhale':
        return `Exhale slowly through your mouth (${8 - seconds}s)`;
      default:
        return 'Press start to begin';
    }
  };
  
  const getBreathingCircleSize = () => {
    if (breathingPhase === 'inhale') {
      return 100 + (seconds / 4) * 50;
    } else if (breathingPhase === 'hold') {
      return 150;
    } else if (breathingPhase === 'exhale') {
      return 150 - (seconds / 8) * 50;
    }
    return 100;
  };
  
  // Journal functions
  const refreshPrompt = () => {
    setJournalPrompt(getRandomPrompt());
  };
  
  const saveJournalEntry = () => {
    if (!journalEntry.trim()) {
      toast({
        title: "Empty entry",
        description: "Please write something before saving.",
        variant: "destructive"
      });
      return;
    }
    
    const newEntry = `${new Date().toLocaleString()}\n\nPrompt: ${journalPrompt}\n\n${journalEntry}`;
    const updatedEntries = [newEntry, ...savedEntries];
    
    setSavedEntries(updatedEntries);
    localStorage.setItem('journalEntries', JSON.stringify(updatedEntries));
    
    setJournalEntry('');
    refreshPrompt();
    
    toast({
      title: "Journal entry saved",
      description: "Your reflection has been saved successfully.",
    });
  };
  
  return (
    <PageContainer>
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-bold mb-2">Coping Tools</h1>
          <p className="text-muted-foreground">
            Practical exercises and techniques to manage stress and improve your wellbeing
          </p>
        </div>
        
        <Tabs defaultValue="breathing" className="space-y-6">
          <TabsList className="grid grid-cols-3 gap-2">
            <TabsTrigger value="breathing" className="flex items-center gap-2">
              <RefreshCw size={16} />
              <span>Breathing</span>
            </TabsTrigger>
            <TabsTrigger value="journal" className="flex items-center gap-2">
              <BookOpen size={16} />
              <span>Journaling</span>
            </TabsTrigger>
            <TabsTrigger value="cbt" className="flex items-center gap-2">
              <Lightbulb size={16} />
              <span>CBT Tips</span>
            </TabsTrigger>
          </TabsList>
          
          {/* Breathing Exercise Tab */}
          <TabsContent value="breathing" className="space-y-4">
            <Card className="wellness-card">
              <CardHeader>
                <CardTitle>4-7-8 Breathing Exercise</CardTitle>
                <CardDescription>
                  This technique helps reduce anxiety, manage stress, and improve sleep.
                </CardDescription>
              </CardHeader>
              <CardContent className="flex flex-col items-center">
                <div className="flex flex-col items-center justify-center mb-8">
                  <div 
                    className={`
                      rounded-full bg-wellness-accent flex items-center justify-center
                      ${isBreathingActive ? 'animate-breathe-slow' : ''}
                      transition-all duration-1000
                    `}
                    style={{ 
                      width: `${getBreathingCircleSize()}px`, 
                      height: `${getBreathingCircleSize()}px` 
                    }}
                  >
                    <Clock className="h-8 w-8 text-wellness-primary" />
                  </div>
                  <div className="text-lg font-medium mt-6">
                    {getBreathingInstruction()}
                  </div>
                  {isBreathingActive && (
                    <div className="text-sm text-muted-foreground mt-2">
                      Completed breaths: {totalBreaths}
                    </div>
                  )}
                </div>
                
                <div className="text-sm text-muted-foreground max-w-md text-center mb-6">
                  <p className="mb-2"><strong>How it works:</strong></p>
                  <p className="mb-1">1. <strong>Inhale</strong> quietly through your nose for 4 seconds</p>
                  <p className="mb-1">2. <strong>Hold</strong> your breath for 7 seconds</p>
                  <p>3. <strong>Exhale</strong> completely through your mouth for 8 seconds</p>
                </div>
              </CardContent>
              <CardFooter className="flex justify-center">
                <Button
                  onClick={toggleBreathing}
                  className={`wellness-button flex items-center gap-2 ${isBreathingActive ? 'bg-red-500 hover:bg-red-600' : 'wellness-button-primary'}`}
                >
                  {isBreathingActive ? (
                    <>
                      <Pause size={16} />
                      <span>Stop</span>
                    </>
                  ) : (
                    <>
                      <Play size={16} />
                      <span>Start Breathing</span>
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
            
            <Card className="wellness-card">
              <CardHeader>
                <CardTitle>Benefits of Deep Breathing</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle size={18} className="text-wellness-primary mt-0.5 shrink-0" />
                    <span>Activates the parasympathetic nervous system, reducing stress hormones</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle size={18} className="text-wellness-primary mt-0.5 shrink-0" />
                    <span>Lowers heart rate and blood pressure</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle size={18} className="text-wellness-primary mt-0.5 shrink-0" />
                    <span>Improves concentration and emotional regulation</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle size={18} className="text-wellness-primary mt-0.5 shrink-0" />
                    <span>Helps manage anxiety and panic symptoms</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle size={18} className="text-wellness-primary mt-0.5 shrink-0" />
                    <span>Promotes better sleep when practiced before bedtime</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Journaling Tab */}
          <TabsContent value="journal" className="space-y-6">
            <Card className="wellness-card">
              <CardHeader>
                <CardTitle>Reflective Journaling</CardTitle>
                <CardDescription>
                  Express your thoughts and feelings in response to the prompt below.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-accent/50 p-4 rounded-lg">
                  <p className="font-medium text-center">{journalPrompt}</p>
                </div>
                
                <div>
                  <Textarea
                    placeholder="Start writing your thoughts here..."
                    className="wellness-input resize-none min-h-[200px]"
                    value={journalEntry}
                    onChange={(e) => setJournalEntry(e.target.value)}
                  />
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button 
                  variant="outline" 
                  onClick={refreshPrompt}
                  className="flex items-center gap-2"
                >
                  <RefreshCw size={16} />
                  <span>New Prompt</span>
                </Button>
                <Button 
                  onClick={saveJournalEntry}
                  className="wellness-button-primary flex items-center gap-2"
                >
                  <Save size={16} />
                  <span>Save Entry</span>
                </Button>
              </CardFooter>
            </Card>
            
            <Card className="wellness-card">
              <CardHeader>
                <CardTitle>Your Journal Entries</CardTitle>
                <CardDescription>
                  Review your past reflections and track your emotional journey.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {savedEntries.length > 0 ? (
                  <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2">
                    {savedEntries.map((entry, index) => (
                      <div 
                        key={index} 
                        className="p-4 border rounded-lg bg-card"
                      >
                        <p className="text-sm text-muted-foreground mb-2">
                          {entry.split('\n\n')[0]}
                        </p>
                        <p className="italic mb-2">
                          {entry.split('\n\n')[1]}
                        </p>
                        <p className="whitespace-pre-wrap">
                          {entry.split('\n\n').slice(2).join('\n\n')}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <BookOpen className="h-10 w-10 text-muted-foreground mx-auto mb-2" />
                    <p className="text-muted-foreground">No entries yet</p>
                    <p className="text-sm text-muted-foreground">
                      Your saved journal entries will appear here
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* CBT Tips Tab */}
          <TabsContent value="cbt" className="space-y-6">
            <Card className="wellness-card">
              <CardHeader>
                <CardTitle>Cognitive Behavioral Therapy Skills</CardTitle>
                <CardDescription>
                  Evidence-based techniques to help change negative thought patterns and behaviors.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {cbtTips.map((tip, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <h3 className="font-semibold text-lg mb-2 flex items-center gap-2">
                        <Lightbulb size={18} className="text-wellness-primary" />
                        <span>{tip.title}</span>
                      </h3>
                      <p className="text-muted-foreground">{tip.description}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <Card className="wellness-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Music size={20} />
                  <span>Guided Meditation</span>
                </CardTitle>
                <CardDescription>
                  Take a break with this calming guided meditation session.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="aspect-video rounded-lg overflow-hidden">
                  <iframe
                    width="100%"
                    height="100%"
                    src="https://www.youtube.com/embed/O-6f5wQXSu8"
                    title="Guided Meditation for Anxiety"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                </div>
                <p className="text-sm text-muted-foreground mt-4">
                  This 10-minute guided meditation helps reduce anxiety and promote relaxation.
                  Find a quiet space, sit comfortably, and follow along with the audio instructions.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PageContainer>
  );
}
