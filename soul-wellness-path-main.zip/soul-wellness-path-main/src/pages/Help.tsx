
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import PageContainer from '@/components/PageContainer';
import { Phone, Globe, Clock, AlertTriangle, Info } from 'lucide-react';

interface HelplineInfo {
  name: string;
  phone: string;
  hours: string;
  website?: string;
  description: string;
}

const helplinesByCountry: Record<string, HelplineInfo[]> = {
  "India": [
    {
      name: "AASRA",
      phone: "91-9820466726",
      hours: "24/7",
      website: "http://www.aasra.info/",
      description: "A crisis intervention center for the depressed and suicidal."
    },
    {
      name: "Roshni",
      phone: "+91-40-66202000",
      hours: "11am to 9pm, all days",
      website: "http://www.roshnihyd.org/",
      description: "Helpline for individuals in emotional distress and suicidal crisis."
    },
    {
      name: "COOJ Mental Health Foundation",
      phone: "0832-2252525",
      hours: "Monday to Friday, 1pm to 7pm",
      website: "http://www.cooj.info/",
      description: "Offers telephone counseling and guidance to the distressed."
    }
  ],
  "United States": [
    {
      name: "National Suicide Prevention Lifeline",
      phone: "988 or 1-800-273-8255",
      hours: "24/7",
      website: "https://suicidepreventionlifeline.org/",
      description: "Provides free and confidential support for people in distress and crisis resources."
    },
    {
      name: "Crisis Text Line",
      phone: "Text HOME to 741741",
      hours: "24/7",
      website: "https://www.crisistextline.org/",
      description: "Free mental health support via text message."
    },
    {
      name: "SAMHSA's National Helpline",
      phone: "1-800-662-4357",
      hours: "24/7, 365 days a year",
      website: "https://www.samhsa.gov/find-help/national-helpline",
      description: "Treatment referral and information service for individuals facing mental health or substance use disorders."
    }
  ],
  "Global": [
    {
      name: "International Association for Suicide Prevention",
      phone: "Various by country",
      hours: "Varies",
      website: "https://www.iasp.info/resources/Crisis_Centres/",
      description: "Provides crisis center information worldwide."
    },
    {
      name: "Befrienders Worldwide",
      phone: "Various by country",
      hours: "Varies",
      website: "https://www.befrienders.org/",
      description: "Volunteer action to prevent suicide with helplines across the globe."
    }
  ]
};

const faqs = [
  {
    question: "How do I know if I'm having a mental health crisis?",
    answer: "Signs of a mental health crisis may include: having thoughts of harming yourself or others, experiencing extreme mood swings, having difficulty carrying out daily activities, showing dramatic changes in eating or sleeping habits, or feeling overwhelmed by your circumstances. If you're in doubt, it's always better to reach out for help."
  },
  {
    question: "What should I expect when calling a crisis helpline?",
    answer: "When you call a crisis helpline, a trained counselor or volunteer will listen to your concerns without judgment. They may ask questions to better understand your situation, provide emotional support, and offer resources or referrals. All calls are confidential, and you can remain anonymous if you prefer."
  },
  {
    question: "Can I call a crisis line if I'm concerned about someone else?",
    answer: "Absolutely. Crisis lines welcome calls from those who are concerned about the mental health or safety of a friend, family member, or anyone else. They can provide guidance on how to best support your loved one and connect them with appropriate resources."
  },
  {
    question: "What if I need in-person help right away?",
    answer: "If you or someone else is in immediate danger, call your local emergency number (such as 911 in the US). You can also go to your nearest emergency room or urgent care psychiatric facility. Many communities also have mobile crisis teams that can come to your location."
  },
  {
    question: "Are crisis helplines only for suicidal thoughts?",
    answer: "No, crisis helplines are available for a wide range of mental health concerns, not just suicidal thoughts. You can call for anxiety, depression, grief, relationship problems, substance abuse issues, or any situation causing you significant distress."
  }
];

export default function Help() {
  return (
    <PageContainer>
      <div className="max-w-4xl mx-auto">
        <div className="border-l-4 border-red-500 pl-4 mb-8">
          <h1 className="text-2xl md:text-3xl font-bold mb-2 flex items-center gap-2">
            <AlertTriangle className="text-red-500" />
            <span>Crisis Support & Help Resources</span>
          </h1>
          <p className="text-muted-foreground">
            If you're experiencing a mental health emergency or having thoughts of harming yourself, please reach out for immediate help.
          </p>
        </div>

        <div className="mb-8">
          <Card className="bg-red-50 border-red-200">
            <CardContent className="pt-6">
              <div className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left">
                <Phone size={40} className="text-red-500" />
                <div>
                  <h2 className="text-xl font-bold">In an immediate crisis?</h2>
                  <p className="text-gray-700">
                    If you or someone else is in immediate danger, call emergency services:
                  </p>
                  <div className="font-bold text-2xl mt-2">911 (US) • 112 (EU) • 999 (UK) • 000 (AU)</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold">Helplines by Country</h2>
            <Select defaultValue="India">
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select country" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="India">India</SelectItem>
                <SelectItem value="United States">United States</SelectItem>
                <SelectItem value="Global">Global Resources</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-4">
            {helplinesByCountry["India"].map((helpline, index) => (
              <Card key={index} className="wellness-card">
                <CardHeader className="pb-2">
                  <CardTitle>{helpline.name}</CardTitle>
                  {helpline.description && <CardDescription>{helpline.description}</CardDescription>}
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Phone size={18} className="text-wellness-primary" />
                      <a href={`tel:${helpline.phone.replace(/[^0-9+]/g, '')}`} className="font-medium text-lg">
                        {helpline.phone}
                      </a>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock size={18} className="text-wellness-secondary" />
                      <span>{helpline.hours}</span>
                    </div>
                    {helpline.website && (
                      <div className="flex items-center gap-2">
                        <Globe size={18} className="text-wellness-secondary" />
                        <a 
                          href={helpline.website} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-wellness-primary hover:underline"
                        >
                          Visit Website
                        </a>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="mb-8">
          <h2 className="text-xl font-bold mb-4">Frequently Asked Questions</h2>
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left">
                  <div className="flex items-start gap-2">
                    <Info size={18} className="text-wellness-primary shrink-0 mt-0.5" />
                    <span>{faq.question}</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        <Card className="wellness-card mb-8">
          <CardHeader>
            <CardTitle>What to Expect During a Crisis</CardTitle>
            <CardDescription>
              Understanding the process can help reduce anxiety about reaching out
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="border rounded-lg p-4">
                <h3 className="font-medium mb-2">When you call a crisis line:</h3>
                <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                  <li>A trained counselor will answer (may be a short wait)</li>
                  <li>The call is confidential and often anonymous</li>
                  <li>You'll be asked about your situation and feelings</li>
                  <li>The counselor will listen without judgment</li>
                  <li>They may ask if you're having thoughts of suicide</li>
                  <li>They'll help you develop a safety plan if needed</li>
                </ul>
              </div>

              <div className="border rounded-lg p-4">
                <h3 className="font-medium mb-2">After your call:</h3>
                <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                  <li>You might receive referrals to local resources</li>
                  <li>You can call back anytime you need more support</li>
                  <li>Some services offer follow-up calls</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="text-center p-6 bg-wellness-accent rounded-lg">
          <h2 className="text-xl font-bold mb-2">Remember, you're not alone</h2>
          <p className="mb-4">
            Reaching out is a sign of strength, not weakness. Help is available whenever you need it.
          </p>
          <Button className="wellness-button-primary">
            <Phone className="mr-2 h-4 w-4" /> Call a Helpline
          </Button>
        </div>
      </div>
    </PageContainer>
  );
}
