
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import { Progress } from "@/components/ui/progress";
import PageContainer from '@/components/PageContainer';
import { ArrowLeft, ArrowRight, Check } from 'lucide-react';

const questions = [
  {
    id: 1,
    question: "How often do you feel overwhelmed by your responsibilities?",
    options: ["Never", "Rarely", "Sometimes", "Often", "Always"]
  },
  {
    id: 2,
    question: "When faced with a challenging situation, do you typically:",
    options: [
      "Avoid it completely",
      "Procrastinate dealing with it",
      "Ask others to handle it",
      "Face it with some hesitation",
      "Tackle it head-on"
    ]
  },
  {
    id: 3,
    question: "How would you rate your sleep quality over the past week?",
    options: ["Very poor", "Poor", "Fair", "Good", "Excellent"]
  },
  {
    id: 4,
    question: "How often do you engage in activities purely for enjoyment?",
    options: ["Never", "Rarely", "Sometimes", "Often", "Daily"]
  },
  {
    id: 5,
    question: "When you make a mistake, how do you typically respond?",
    options: [
      "Extremely self-critical",
      "Dwell on it for days",
      "Feel disappointed but move on",
      "Learn from it",
      "Accept it as part of growth"
    ]
  },
  {
    id: 6,
    question: "How often do you feel disconnected from others?",
    options: ["Never", "Rarely", "Sometimes", "Often", "Always"]
  },
  {
    id: 7,
    question: "When something good happens, how long does your positive mood typically last?",
    options: [
      "Moments only",
      "Less than an hour",
      "Several hours",
      "The whole day",
      "Several days"
    ]
  },
  {
    id: 8,
    question: "How satisfied are you with your ability to handle stress?",
    options: [
      "Very dissatisfied",
      "Dissatisfied",
      "Neutral",
      "Satisfied",
      "Very satisfied"
    ]
  },
  {
    id: 9,
    question: "How often do you engage in physical exercise?",
    options: [
      "Never",
      "A few times a month",
      "Once a week",
      "2-3 times a week",
      "Almost daily"
    ]
  },
  {
    id: 10,
    question: "How would you describe your ability to focus on tasks?",
    options: [
      "Cannot focus at all",
      "Easily distracted",
      "Can focus with effort",
      "Focus well with occasional breaks",
      "Deeply focused for extended periods"
    ]
  }
];

export default function Questionnaire() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>(Array(questions.length).fill(-1));
  const [selectedOption, setSelectedOption] = useState<number>(-1);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const progress = ((currentQuestion + 1) / questions.length) * 100;
  
  const handleOptionSelect = (optionIndex: number) => {
    setSelectedOption(optionIndex);
  };
  
  const handleNext = () => {
    // Save the answer
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = selectedOption;
    setAnswers(newAnswers);
    
    // Move to next question or submit if last
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedOption(answers[currentQuestion + 1]);
    } else {
      handleSubmit();
    }
  };
  
  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
      setSelectedOption(answers[currentQuestion - 1]);
    }
  };
  
  const handleSubmit = () => {
    setLoading(true);
    
    // Check for unanswered questions
    if (answers.includes(-1)) {
      toast({
        title: "Please answer all questions",
        description: "Some questions are still unanswered.",
        variant: "destructive"
      });
      
      // Go to the first unanswered question
      const firstUnanswered = answers.findIndex(a => a === -1);
      setCurrentQuestion(firstUnanswered);
      setSelectedOption(-1);
      setLoading(false);
      return;
    }
    
    // Simulate API call
    setTimeout(() => {
      localStorage.setItem('questionnaire', JSON.stringify(answers));
      
      toast({
        title: "Assessment completed",
        description: "Thank you for completing the mental health assessment.",
      });
      
      // Navigate to dashboard or results page
      navigate('/dashboard');
      setLoading(false);
    }, 1500);
  };

  const question = questions[currentQuestion];
  
  return (
    <PageContainer>
      <div className="max-w-2xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-2xl md:text-3xl font-bold mb-2">Mental Wellness Assessment</h1>
          <p className="text-muted-foreground">
            This questionnaire helps us understand your mental wellbeing. Your answers are confidential.
          </p>
        </div>
        
        <div className="mb-6">
          <div className="flex justify-between text-sm mb-2">
            <span>Question {currentQuestion + 1} of {questions.length}</span>
            <span>{Math.round(progress)}% complete</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        <Card className="wellness-card mb-6">
          <CardContent className="pt-6">
            <h2 className="text-xl font-semibold mb-6">{question.question}</h2>
            <div className="space-y-3">
              {question.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleOptionSelect(index)}
                  className={`relative w-full text-left p-4 rounded-xl border transition-all ${
                    selectedOption === index
                      ? "border-wellness-primary bg-wellness-accent"
                      : "border-input hover:border-wellness-primary/50 hover:bg-wellness-accent/30"
                  }`}
                >
                  <span>{option}</span>
                  {selectedOption === index && (
                    <div className="absolute right-4 top-1/2 transform -translate-y-1/2">
                      <Check className="h-5 w-5 text-wellness-primary" />
                    </div>
                  )}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-between">
          <Button
            onClick={handlePrevious}
            disabled={currentQuestion === 0}
            variant="outline"
            className="flex items-center gap-2"
          >
            <ArrowLeft size={16} />
            Previous
          </Button>
          
          <Button
            onClick={handleNext}
            disabled={selectedOption === -1 || loading}
            className="wellness-button-primary flex items-center gap-2"
          >
            {currentQuestion < questions.length - 1 ? (
              <>
                Next
                <ArrowRight size={16} />
              </>
            ) : loading ? (
              "Submitting..."
            ) : (
              "Complete Assessment"
            )}
          </Button>
        </div>
      </div>
    </PageContainer>
  );
}
