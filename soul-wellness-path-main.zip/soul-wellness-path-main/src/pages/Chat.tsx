
import { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import PageContainer from '@/components/PageContainer';
import { Send, PlusCircle, ArrowDown } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

// Mock chatbot responses
const getBotResponse = (message: string): Promise<string> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const lowerMessage = message.toLowerCase();
      
      if (lowerMessage.includes('anxious') || lowerMessage.includes('anxiety')) {
        resolve("It sounds like you're experiencing anxiety. This is a common feeling that many people face. Try some deep breathing exercises: breathe in for 4 counts, hold for 7, and exhale for 8. Would you like me to recommend some other coping strategies or should we explore what might be triggering these feelings?");
      } else if (lowerMessage.includes('sleep') || lowerMessage.includes('insomnia')) {
        resolve("Sleep difficulties can be frustrating. Some helpful practices include maintaining a consistent sleep schedule, creating a relaxing bedtime routine, and limiting screen time before bed. Would you like to try our guided sleep meditation in the coping tools section?");
      } else if (lowerMessage.includes('sad') || lowerMessage.includes('depress')) {
        resolve("I'm sorry to hear you're feeling this way. Sometimes talking to a professional can really help when feelings of sadness persist. Would you like me to suggest some self-care activities that might help lift your mood in the meantime?");
      } else if (lowerMessage.includes('doctor') || lowerMessage.includes('therapist') || lowerMessage.includes('professional')) {
        resolve("Based on what you've shared, speaking with a mental health professional could be beneficial. Psychiatrists can help with medication management, while psychologists and therapists focus on therapeutic approaches. Would you like me to help you find local mental health resources?");
      } else if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('hey')) {
        resolve("Hello! I'm your SoulWellness assistant. How are you feeling today? I'm here to listen and offer support with whatever you'd like to discuss about your mental wellbeing.");
      } else {
        resolve("Thank you for sharing that with me. Would you like to tell me more about how this has been affecting you? The more you share, the better I can understand how to support you.");
      }
    }, 1000);
  });
};

const initialMessages: Message[] = [
  {
    id: '1',
    text: "Hello! I'm your mental health assistant. How are you feeling today?",
    sender: 'bot',
    timestamp: new Date()
  }
];

export default function Chat() {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [showScrollDown, setShowScrollDown] = useState(false);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  // Handle scroll to detect when not at bottom
  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
    const atBottom = scrollHeight - scrollTop - clientHeight < 50;
    setShowScrollDown(!atBottom);
  };
  
  const handleSend = async () => {
    if (!input.trim()) return;
    
    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      text: input,
      sender: 'user',
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);
    
    // Get bot response
    try {
      const response = await getBotResponse(input);
      
      // Add bot message
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: response,
        sender: 'bot',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      console.error('Error getting bot response:', error);
    } finally {
      setIsTyping(false);
    }
  };
  
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const suggestedQuestions = [
    "I've been feeling anxious lately",
    "I'm having trouble sleeping",
    "I feel sad most of the time",
    "What type of doctor should I see?"
  ];
  
  return (
    <PageContainer className="flex flex-col p-0 md:py-8">
      <div className="max-w-4xl w-full mx-auto flex flex-col h-[calc(100vh-4rem)]">
        <div className="px-4 py-3 border-b">
          <h1 className="text-xl font-semibold">Mental Health Assistant</h1>
          <p className="text-sm text-muted-foreground">
            Share how you're feeling, and I'll do my best to help you
          </p>
        </div>
        
        <div 
          className="flex-1 overflow-y-auto px-4 py-6 space-y-4"
          onScroll={handleScroll}
        >
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`
                  chat-bubble-${message.sender} 
                  max-w-[85%] md:max-w-[70%]
                `}
              >
                <p className="whitespace-pre-wrap">{message.text}</p>
                <p className="text-xs opacity-70 mt-1 text-right">
                  {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          ))}
          
          {isTyping && (
            <div className="flex justify-start">
              <div className="chat-bubble-bot">
                <div className="flex space-x-2">
                  <div className="h-2 w-2 rounded-full bg-wellness-primary animate-bounce"></div>
                  <div className="h-2 w-2 rounded-full bg-wellness-primary animate-bounce [animation-delay:150ms]"></div>
                  <div className="h-2 w-2 rounded-full bg-wellness-primary animate-bounce [animation-delay:300ms]"></div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
        
        {messages.length === 1 && (
          <div className="px-4 mb-4">
            <p className="text-sm text-muted-foreground mb-2">Suggested questions:</p>
            <div className="flex flex-wrap gap-2">
              {suggestedQuestions.map((question, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="text-sm"
                  onClick={() => {
                    setInput(question);
                  }}
                >
                  {question}
                </Button>
              ))}
            </div>
          </div>
        )}
        
        <div className="p-4 border-t">
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              className="rounded-full"
              aria-label="Add attachment"
            >
              <PlusCircle size={20} />
            </Button>
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type your message..."
              className="wellness-input"
            />
            <Button
              onClick={handleSend}
              disabled={!input.trim() || isTyping}
              className="wellness-button-primary px-4 rounded-full"
              aria-label="Send message"
            >
              <Send size={18} />
            </Button>
          </div>
        </div>
      </div>
      
      {showScrollDown && (
        <Button
          variant="secondary"
          size="icon"
          className="rounded-full fixed bottom-20 right-8 shadow-md"
          onClick={scrollToBottom}
        >
          <ArrowDown size={18} />
        </Button>
      )}
    </PageContainer>
  );
}
