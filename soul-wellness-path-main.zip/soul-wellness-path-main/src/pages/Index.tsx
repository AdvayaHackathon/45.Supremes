
import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, MessageCircle, BarChart, Heart, Brain, Users, Shield, CheckCircle } from 'lucide-react';

const Index = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-wellness-accent to-background py-16 md:py-24">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center text-center space-y-4 md:space-y-8">
            <div className="h-16 w-16 rounded-full bg-wellness-primary flex items-center justify-center">
              <Brain size={32} className="text-white" />
            </div>
            <h1 className="text-3xl md:text-5xl font-bold tracking-tighter max-w-3xl animate-fade-in">
              Your Journey to Mental Wellbeing Starts Here
            </h1>
            <p className="text-muted-foreground text-lg md:text-xl max-w-[700px] animate-fade-in">
              Assess, track, and improve your mental health with personalized insights, AI-powered support, and evidence-based tools.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 animate-fade-in">
              <Button asChild className="wellness-button-primary" size="lg">
                <Link to="/register" className="flex items-center gap-2">
                  <span>Get Started</span>
                  <ArrowRight size={16} />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/login">Sign In</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 md:py-24">
        <div className="container px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tighter mb-4">
              Comprehensive Mental Health Support
            </h2>
            <p className="text-muted-foreground text-lg max-w-[700px] mx-auto">
              Our platform offers a range of tools and resources to support your mental wellbeing journey.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="wellness-card flex flex-col items-center text-center p-8">
              <div className="h-12 w-12 rounded-full bg-wellness-accent flex items-center justify-center mb-6">
                <MessageCircle size={24} className="text-wellness-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">AI-Powered Chat Support</h3>
              <p className="text-muted-foreground mb-4">
                Talk to our empathetic AI assistant about your feelings, concerns, and mental health questions.
              </p>
              <Button asChild variant="link" className="mt-auto">
                <Link to="/chat" className="flex items-center gap-1">
                  <span>Try it now</span>
                  <ArrowRight size={14} />
                </Link>
              </Button>
            </Card>

            <Card className="wellness-card flex flex-col items-center text-center p-8">
              <div className="h-12 w-12 rounded-full bg-wellness-accent flex items-center justify-center mb-6">
                <BarChart size={24} className="text-wellness-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Mood Tracking</h3>
              <p className="text-muted-foreground mb-4">
                Monitor your emotions over time with our intuitive mood tracker and gain insights into your patterns.
              </p>
              <Button asChild variant="link" className="mt-auto">
                <Link to="/mood" className="flex items-center gap-1">
                  <span>Track your mood</span>
                  <ArrowRight size={14} />
                </Link>
              </Button>
            </Card>

            <Card className="wellness-card flex flex-col items-center text-center p-8">
              <div className="h-12 w-12 rounded-full bg-wellness-accent flex items-center justify-center mb-6">
                <Heart size={24} className="text-wellness-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Coping Tools</h3>
              <p className="text-muted-foreground mb-4">
                Access evidence-based techniques including breathing exercises, guided meditation, and journaling.
              </p>
              <Button asChild variant="link" className="mt-auto">
                <Link to="/tools" className="flex items-center gap-1">
                  <span>Explore tools</span>
                  <ArrowRight size={14} />
                </Link>
              </Button>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 md:py-24 bg-wellness-accent/50">
        <div className="container px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tighter mb-4">
              How It Works
            </h2>
            <p className="text-muted-foreground text-lg max-w-[700px] mx-auto">
              A simple, evidence-based approach to improving your mental wellbeing
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="flex flex-col items-center text-center">
              <div className="h-12 w-12 rounded-full bg-wellness-primary flex items-center justify-center mb-4">
                <span className="text-white font-bold">1</span>
              </div>
              <h3 className="text-lg font-bold mb-2">Take the Assessment</h3>
              <p className="text-muted-foreground">
                Complete our comprehensive mental health questionnaire
              </p>
            </div>

            <div className="flex flex-col items-center text-center">
              <div className="h-12 w-12 rounded-full bg-wellness-primary flex items-center justify-center mb-4">
                <span className="text-white font-bold">2</span>
              </div>
              <h3 className="text-lg font-bold mb-2">Get Personalized Insights</h3>
              <p className="text-muted-foreground">
                Receive an analysis of your strengths and areas for improvement
              </p>
            </div>

            <div className="flex flex-col items-center text-center">
              <div className="h-12 w-12 rounded-full bg-wellness-primary flex items-center justify-center mb-4">
                <span className="text-white font-bold">3</span>
              </div>
              <h3 className="text-lg font-bold mb-2">Use the Tools</h3>
              <p className="text-muted-foreground">
                Access our suite of coping tools tailored to your needs
              </p>
            </div>

            <div className="flex flex-col items-center text-center">
              <div className="h-12 w-12 rounded-full bg-wellness-primary flex items-center justify-center mb-4">
                <span className="text-white font-bold">4</span>
              </div>
              <h3 className="text-lg font-bold mb-2">Track Your Progress</h3>
              <p className="text-muted-foreground">
                Monitor changes in your wellbeing over time
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 md:py-24">
        <div className="container px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tighter mb-4">
              What Our Users Say
            </h2>
            <p className="text-muted-foreground text-lg max-w-[700px] mx-auto">
              Hear from people who have improved their mental wellbeing with our platform
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="wellness-card p-6">
              <CardContent className="pt-6">
                <div className="flex flex-col h-full">
                  <div className="flex-1">
                    <p className="italic mb-4">
                      "The daily mood tracking has really helped me identify patterns in my anxiety. Now I can see what triggers it and take steps to manage it better."
                    </p>
                    <div className="flex items-center text-amber-500 mb-4">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <svg key={star} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                          <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" />
                        </svg>
                      ))}
                    </div>
                  </div>
                  <div className="mt-auto">
                    <div className="font-semibold">Sarah T.</div>
                    <div className="text-sm text-muted-foreground">Anxiety Management</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="wellness-card p-6">
              <CardContent className="pt-6">
                <div className="flex flex-col h-full">
                  <div className="flex-1">
                    <p className="italic mb-4">
                      "The breathing exercises have become part of my daily routine. I use them during work breaks and before bed. My stress levels have decreased significantly."
                    </p>
                    <div className="flex items-center text-amber-500 mb-4">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <svg key={star} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                          <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" />
                        </svg>
                      ))}
                    </div>
                  </div>
                  <div className="mt-auto">
                    <div className="font-semibold">Mike L.</div>
                    <div className="text-sm text-muted-foreground">Stress Reduction</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="wellness-card p-6">
              <CardContent className="pt-6">
                <div className="flex flex-col h-full">
                  <div className="flex-1">
                    <p className="italic mb-4">
                      "The AI chat support feels very natural and understanding. It's always available when I need someone to talk to about my feelings, no matter the time."
                    </p>
                    <div className="flex items-center text-amber-500 mb-4">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <svg key={star} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                          <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" />
                        </svg>
                      ))}
                    </div>
                  </div>
                  <div className="mt-auto">
                    <div className="font-semibold">Priya K.</div>
                    <div className="text-sm text-muted-foreground">Emotional Support</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-wellness-primary text-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center text-center space-y-4">
            <h2 className="text-3xl font-bold tracking-tighter mb-4">
              Ready to Start Your Wellness Journey?
            </h2>
            <p className="text-white/90 text-lg max-w-[700px] mx-auto mb-8">
              Join thousands of users who have improved their mental wellbeing with our platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button asChild className="bg-white text-wellness-primary hover:bg-white/90" size="lg">
                <Link to="/register">Create Account</Link>
              </Button>
              <Button asChild variant="outline" className="border-white text-white hover:bg-white/10" size="lg">
                <Link to="/login">Sign In</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Highlights */}
      <section className="py-16 md:py-24">
        <div className="container px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tighter mb-4">
              Why Choose Us
            </h2>
            <p className="text-muted-foreground text-lg max-w-[700px] mx-auto">
              Our platform is designed with your mental wellbeing as the top priority
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="flex items-start gap-4">
              <div className="h-10 w-10 rounded-full bg-wellness-accent flex items-center justify-center shrink-0">
                <Shield size={20} className="text-wellness-primary" />
              </div>
              <div>
                <h3 className="text-lg font-bold mb-2">Privacy Protected</h3>
                <p className="text-muted-foreground">
                  Your data is encrypted and securely stored. We never share your information with third parties.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="h-10 w-10 rounded-full bg-wellness-accent flex items-center justify-center shrink-0">
                <Brain size={20} className="text-wellness-primary" />
              </div>
              <div>
                <h3 className="text-lg font-bold mb-2">Evidence-Based</h3>
                <p className="text-muted-foreground">
                  Our tools and techniques are grounded in psychological research and proven therapeutic approaches.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="h-10 w-10 rounded-full bg-wellness-accent flex items-center justify-center shrink-0">
                <Users size={20} className="text-wellness-primary" />
              </div>
              <div>
                <h3 className="text-lg font-bold mb-2">Community Support</h3>
                <p className="text-muted-foreground">
                  Connect with resources, professionals, and others on similar mental health journeys.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="h-10 w-10 rounded-full bg-wellness-accent flex items-center justify-center shrink-0">
                <CheckCircle size={20} className="text-wellness-primary" />
              </div>
              <div>
                <h3 className="text-lg font-bold mb-2">Personalized Experience</h3>
                <p className="text-muted-foreground">
                  Receive recommendations and insights tailored to your unique mental health profile.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="h-10 w-10 rounded-full bg-wellness-accent flex items-center justify-center shrink-0">
                <Heart size={20} className="text-wellness-primary" />
              </div>
              <div>
                <h3 className="text-lg font-bold mb-2">Holistic Approach</h3>
                <p className="text-muted-foreground">
                  We address mental wellbeing from multiple angles: emotional, cognitive, behavioral, and social.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="h-10 w-10 rounded-full bg-wellness-accent flex items-center justify-center shrink-0">
                <MessageCircle size={20} className="text-wellness-primary" />
              </div>
              <div>
                <h3 className="text-lg font-bold mb-2">24/7 Availability</h3>
                <p className="text-muted-foreground">
                  Our AI support and self-help tools are available whenever you need them, day or night.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer with disclaimer */}
      <footer className="py-12 border-t">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <div className="h-8 w-8 rounded-full bg-wellness-primary flex items-center justify-center">
                  <Heart size={16} className="text-white" />
                </div>
                <span className="font-semibold text-xl">SoulWellness</span>
              </div>
              <p className="text-muted-foreground mb-4">
                Your companion on the journey to better mental health and emotional wellbeing.
              </p>
              <div className="text-sm text-muted-foreground">
                <p className="font-semibold">Important Disclaimer:</p>
                <p>
                  This application is not a replacement for professional mental health services. 
                  If you're experiencing a crisis or need immediate help, please contact emergency services or a mental health professional.
                </p>
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li><Link to="/" className="text-muted-foreground hover:text-wellness-primary">Home</Link></li>
                <li><Link to="/chat" className="text-muted-foreground hover:text-wellness-primary">Chat Support</Link></li>
                <li><Link to="/mood" className="text-muted-foreground hover:text-wellness-primary">Mood Tracker</Link></li>
                <li><Link to="/tools" className="text-muted-foreground hover:text-wellness-primary">Coping Tools</Link></li>
                <li><Link to="/help" className="text-muted-foreground hover:text-wellness-primary">Crisis Support</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Account</h3>
              <ul className="space-y-2">
                <li><Link to="/login" className="text-muted-foreground hover:text-wellness-primary">Sign In</Link></li>
                <li><Link to="/register" className="text-muted-foreground hover:text-wellness-primary">Create Account</Link></li>
                <li><Link to="/dashboard" className="text-muted-foreground hover:text-wellness-primary">Dashboard</Link></li>
              </ul>
            </div>
          </div>
          
          <div className="flex flex-col md:flex-row justify-between items-center mt-12 pt-8 border-t">
            <p className="text-sm text-muted-foreground mb-4 md:mb-0">
              &copy; 2025 SoulWellness. All rights reserved.
            </p>
            <div className="flex space-x-4">
              <Link to="/privacy" className="text-sm text-muted-foreground hover:text-wellness-primary">Privacy Policy</Link>
              <Link to="/terms" className="text-sm text-muted-foreground hover:text-wellness-primary">Terms of Service</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
