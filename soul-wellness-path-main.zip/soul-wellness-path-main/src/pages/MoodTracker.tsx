
import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import PageContainer from '@/components/PageContainer';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, TooltipProps } from 'recharts';
import { BarChart2, CalendarDays, Plus, Calendar } from 'lucide-react';

interface MoodEntry {
  id: string;
  date: string;
  mood: number;
  note: string;
}

// Get formatted date string
const formatDate = (date: Date) => {
  return date.toLocaleDateString('en-US', { 
    weekday: 'short',
    month: 'short', 
    day: 'numeric'
  });
};

// Get formatted time string
const formatTime = (date: Date) => {
  return date.toLocaleTimeString('en-US', { 
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });
};

// Generate initial sample data
const generateSampleData = (): MoodEntry[] => {
  const data: MoodEntry[] = [];
  const now = new Date();
  
  // Generate entries for the last 7 days
  for (let i = 6; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    
    // Skip some days randomly
    if (i !== 0 && i !== 3 && i !== 6) continue;
    
    data.push({
      id: date.getTime().toString(),
      date: date.toISOString(),
      mood: Math.floor(Math.random() * 7) + 3, // Random mood between 3-9
      note: ''
    });
  }
  
  return data;
};

export default function MoodTracker() {
  const [moodEntries, setMoodEntries] = useState<MoodEntry[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentMood, setCurrentMood] = useState(5);
  const [note, setNote] = useState('');
  const [timeframe, setTimeframe] = useState<'week' | 'month'>('week');
  const { toast } = useToast();
  
  // Load mood data from localStorage on component mount
  useEffect(() => {
    const savedEntries = localStorage.getItem('moodEntries');
    if (savedEntries) {
      setMoodEntries(JSON.parse(savedEntries));
    } else {
      // Generate sample data if none exists
      const sampleData = generateSampleData();
      setMoodEntries(sampleData);
      localStorage.setItem('moodEntries', JSON.stringify(sampleData));
    }
  }, []);
  
  // Save mood entries to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('moodEntries', JSON.stringify(moodEntries));
  }, [moodEntries]);
  
  const handleAddMood = () => {
    const now = new Date();
    const newEntry: MoodEntry = {
      id: now.getTime().toString(),
      date: now.toISOString(),
      mood: currentMood,
      note: note
    };
    
    setMoodEntries([...moodEntries, newEntry]);
    setIsDialogOpen(false);
    setCurrentMood(5);
    setNote('');
    
    toast({
      title: "Mood recorded",
      description: "Your mood has been successfully recorded.",
    });
  };
  
  // Prepare chart data
  const getChartData = () => {
    // Sort entries by date
    const sortedEntries = [...moodEntries].sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );
    
    // Filter entries based on timeframe
    const now = new Date();
    const filtered = sortedEntries.filter(entry => {
      const entryDate = new Date(entry.date);
      if (timeframe === 'week') {
        const weekAgo = new Date(now);
        weekAgo.setDate(weekAgo.getDate() - 7);
        return entryDate >= weekAgo;
      } else {
        const monthAgo = new Date(now);
        monthAgo.setMonth(monthAgo.getMonth() - 1);
        return entryDate >= monthAgo;
      }
    });
    
    // Transform entries for chart
    return filtered.map(entry => ({
      date: formatDate(new Date(entry.date)),
      mood: entry.mood,
      fullDate: entry.date,
      note: entry.note
    }));
  };
  
  const chartData = getChartData();
  
  // Custom tooltip for the chart
  const CustomTooltip = ({ active, payload }: TooltipProps<number, string>) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-popover text-popover-foreground p-3 rounded-md shadow-md border text-sm">
          <p className="font-medium">{data.date}</p>
          <p className="text-wellness-primary font-medium">Mood score: {data.mood}/10</p>
          {data.note && (
            <p className="max-w-[200px] mt-1 text-muted-foreground">
              "{data.note}"
            </p>
          )}
        </div>
      );
    }
    return null;
  };
  
  // Get mood description
  const getMoodDescription = (score: number) => {
    if (score <= 2) return "Very low";
    if (score <= 4) return "Low";
    if (score <= 6) return "Neutral";
    if (score <= 8) return "Good";
    return "Excellent";
  };
  
  // Calculate average mood
  const averageMood = chartData.length 
    ? Math.round(chartData.reduce((sum, entry) => sum + entry.mood, 0) / chartData.length * 10) / 10
    : 0;

  // Get most recent entry
  const latestEntry = moodEntries.length
    ? moodEntries.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0]
    : null;
  
  return (
    <PageContainer>
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">Mood Tracker</h1>
            <p className="text-muted-foreground">
              Track and visualize changes in your emotional wellbeing over time
            </p>
          </div>
          <Button 
            onClick={() => setIsDialogOpen(true)}
            className="wellness-button-primary flex items-center gap-2"
          >
            <Plus size={18} />
            <span>Log Mood</span>
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card className="wellness-card col-span-1">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-medium">Current Mood</CardTitle>
            </CardHeader>
            <CardContent>
              {latestEntry ? (
                <div>
                  <div className="flex items-center justify-center">
                    <div className="text-5xl font-bold text-wellness-primary">
                      {latestEntry.mood}
                    </div>
                    <div className="text-2xl text-muted-foreground ml-1">/10</div>
                  </div>
                  <p className="text-center font-medium mt-1">
                    {getMoodDescription(latestEntry.mood)}
                  </p>
                  <p className="text-center text-sm text-muted-foreground mt-3">
                    Recorded: {formatDate(new Date(latestEntry.date))} at {formatTime(new Date(latestEntry.date))}
                  </p>
                </div>
              ) : (
                <div className="text-center py-4">
                  <p className="text-muted-foreground">No mood recorded yet</p>
                  <Button 
                    onClick={() => setIsDialogOpen(true)}
                    variant="link" 
                    className="mt-2"
                  >
                    Record your first mood
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card className="wellness-card col-span-1">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-medium">Average Mood</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center">
                <div className="text-5xl font-bold text-wellness-secondary">
                  {averageMood}
                </div>
                <div className="text-2xl text-muted-foreground ml-1">/10</div>
              </div>
              <p className="text-center font-medium mt-1">
                {getMoodDescription(averageMood)}
              </p>
              <p className="text-center text-sm text-muted-foreground mt-3">
                Based on {chartData.length} entries in the last {timeframe}
              </p>
            </CardContent>
          </Card>
          
          <Card className="wellness-card col-span-1">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-medium">Mood Insights</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="py-4 text-center">
                <p className="text-sm text-muted-foreground mb-2">
                  {chartData.length > 0 
                    ? "Your mood has been relatively stable. Continue tracking to see more patterns."
                    : "Log your mood daily to receive personalized insights."
                  }
                </p>
                <p className="text-sm text-wellness-primary">
                  Tracking consistently gives the best results!
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Card className="wellness-card">
          <CardHeader className="pb-2">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <CardTitle className="flex items-center gap-2">
                <BarChart2 size={20} />
                <span>Mood Over Time</span>
              </CardTitle>
              <div className="flex items-center space-x-2">
                <Button
                  variant={timeframe === 'week' ? 'secondary' : 'ghost'}
                  size="sm"
                  onClick={() => setTimeframe('week')}
                  className="flex items-center gap-1"
                >
                  <CalendarDays size={16} />
                  <span>Week</span>
                </Button>
                <Button
                  variant={timeframe === 'month' ? 'secondary' : 'ghost'}
                  size="sm"
                  onClick={() => setTimeframe('month')}
                  className="flex items-center gap-1"
                >
                  <Calendar size={16} />
                  <span>Month</span>
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {chartData.length > 0 ? (
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={chartData}
                    margin={{ top: 20, right: 20, left: 0, bottom: 0 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                    <XAxis 
                      dataKey="date" 
                      tick={{ fontSize: 12 }}
                      tickMargin={10}
                      stroke="#a1a1aa"
                    />
                    <YAxis 
                      domain={[0, 10]} 
                      ticks={[0, 2, 4, 6, 8, 10]}
                      tick={{ fontSize: 12 }}
                      tickMargin={10}
                      stroke="#a1a1aa"
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Line
                      type="monotone"
                      dataKey="mood"
                      stroke="#9B87F5"
                      strokeWidth={3}
                      dot={{ r: 4, strokeWidth: 2, fill: "#fff" }}
                      activeDot={{ r: 6, strokeWidth: 0, fill: "#9B87F5" }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-[300px] flex items-center justify-center">
                <div className="text-center">
                  <p className="text-muted-foreground mb-2">No mood data available</p>
                  <Button 
                    onClick={() => setIsDialogOpen(true)}
                    variant="secondary"
                  >
                    Log your mood
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* Add Mood Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>How are you feeling?</DialogTitle>
            <DialogDescription>
              Rate your mood on a scale from 1 to 10
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-6">
            <div className="flex items-center justify-center mb-8">
              <div className="text-6xl font-bold text-wellness-primary">{currentMood}</div>
              <div className="text-2xl text-muted-foreground ml-1">/10</div>
            </div>
            
            <div className="mb-8 px-4">
              <Slider
                value={[currentMood]}
                min={1}
                max={10}
                step={1}
                onValueChange={(value) => setCurrentMood(value[0])}
              />
              <div className="flex justify-between text-sm text-muted-foreground mt-2">
                <span>Very low</span>
                <span>Neutral</span>
                <span>Excellent</span>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="note">Add a note (optional)</Label>
              <Textarea
                id="note"
                placeholder="What's contributing to your mood today?"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="wellness-input resize-none h-24"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleAddMood}
              className="wellness-button-primary"
            >
              Save Entry
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageContainer>
  );
}
