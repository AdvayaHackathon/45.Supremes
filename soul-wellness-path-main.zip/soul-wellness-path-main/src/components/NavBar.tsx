
import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Home, MessageCircle, BarChart, Heart, HelpCircle, UserCircle, Menu, X } from "lucide-react";

interface NavItemProps {
  to: string;
  icon: React.ReactNode;
  text: string;
  active?: boolean;
  onClick?: () => void;
}

const NavItem = ({ to, icon, text, active, onClick }: NavItemProps) => (
  <Link 
    to={to} 
    onClick={onClick}
    className={`flex items-center gap-2 p-3 rounded-lg transition-all 
                ${active 
                  ? 'bg-wellness-accent text-wellness-primary font-medium' 
                  : 'text-foreground/70 hover:bg-wellness-accent/50'}`}
  >
    {icon}
    <span>{text}</span>
  </Link>
);

export default function NavBar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  const isActive = (path: string) => location.pathname === path;
  const closeMenu = () => setMobileMenuOpen(false);

  const navItems = [
    { to: "/", icon: <Home size={20} />, text: "Home" },
    { to: "/chat", icon: <MessageCircle size={20} />, text: "Chat" },
    { to: "/mood", icon: <BarChart size={20} />, text: "Mood Tracker" },
    { to: "/tools", icon: <Heart size={20} />, text: "Coping Tools" },
    { to: "/help", icon: <HelpCircle size={20} />, text: "Crisis Support" },
  ];

  return (
    <header className="border-b sticky top-0 z-10 bg-background/95 backdrop-blur-sm">
      <div className="container flex justify-between items-center h-16 px-4 md:px-6">
        <Link to="/" className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-full bg-wellness-primary flex items-center justify-center">
            <Heart size={18} className="text-white" />
          </div>
          <span className="font-semibold text-xl">SoulWellness</span>
        </Link>

        {/* Desktop navigation */}
        <nav className="hidden md:flex items-center gap-2">
          {navItems.map((item) => (
            <NavItem 
              key={item.to} 
              to={item.to} 
              icon={item.icon} 
              text={item.text} 
              active={isActive(item.to)} 
            />
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Button asChild variant="ghost" className="hidden md:flex">
            <Link to="/login" className="gap-2">
              <UserCircle size={20} />
              <span>Login</span>
            </Link>
          </Button>

          {/* Mobile menu button */}
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </Button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 top-16 z-20 bg-background animate-fade-in md:hidden">
          <nav className="flex flex-col p-4">
            {navItems.map((item) => (
              <NavItem 
                key={item.to} 
                to={item.to} 
                icon={item.icon} 
                text={item.text} 
                active={isActive(item.to)} 
                onClick={closeMenu}
              />
            ))}
            <NavItem 
              to="/login" 
              icon={<UserCircle size={20} />} 
              text="Login" 
              onClick={closeMenu}
            />
          </nav>
        </div>
      )}
    </header>
  );
}
