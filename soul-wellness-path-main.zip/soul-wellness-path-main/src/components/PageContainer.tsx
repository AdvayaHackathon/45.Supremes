
import React from 'react';

interface PageContainerProps {
  children: React.ReactNode;
  className?: string;
}

export default function PageContainer({ children, className = '' }: PageContainerProps) {
  return (
    <main className={`container px-4 py-6 md:py-10 min-h-[calc(100vh-4rem)] ${className}`}>
      {children}
    </main>
  );
}
